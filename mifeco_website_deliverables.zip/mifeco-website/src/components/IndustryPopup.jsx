import React, { useState } from 'react';
import { X, Users, GraduationCap, Heart, Cpu, Rocket, Download, FileText, TrendingUp, Shield, Target, Lightbulb } from 'lucide-react';

const IndustryPopup = ({ isOpen, onClose, industry }) => {
  if (!isOpen) return null;

  const industryContent = {
    education: {
      title: "Education Consulting Excellence",
      icon: <GraduationCap className="w-8 h-8 text-blue-600" />,
      subtitle: "Transforming Educational Institutions for the Digital Age",
      description: "MIFECO's education consulting practice has revolutionized how educational institutions operate, learn, and grow. Our comprehensive approach combines strategic planning, technology integration, and operational excellence to create sustainable educational environments that prepare students for tomorrow's challenges.",
      
      caseStudy: {
        title: "Metropolitan University System Transformation",
        challenge: "A major university system with 45,000 students across five campuses was struggling with declining enrollment, outdated technology infrastructure, and fragmented administrative processes. Student satisfaction scores had dropped to 2.8/5, and the institution was facing a $12 million budget deficit.",
        solution: "MIFECO implemented a comprehensive digital transformation strategy that included: unified student information systems, AI-powered student success analytics, streamlined administrative workflows, and innovative online learning platforms. We also redesigned the student experience journey from application to graduation.",
        results: [
          "Increased student enrollment by 23% within 18 months",
          "Improved student satisfaction scores to 4.6/5",
          "Reduced administrative costs by $8.2 million annually",
          "Achieved 95% student retention rate (up from 78%)",
          "Launched 15 new online degree programs generating $4.5M in additional revenue"
        ],
        testimonial: "MIFECO didn't just consult - they became true partners in our transformation. Their education expertise combined with cutting-edge technology solutions helped us not only survive but thrive in today's competitive landscape.",
        client: "Dr. Sarah Mitchell, President, Metropolitan University System"
      },

      services: [
        {
          name: "Strategic Academic Planning",
          description: "Comprehensive curriculum design, program development, and academic excellence frameworks"
        },
        {
          name: "Digital Learning Transformation",
          description: "Implementation of advanced learning management systems, virtual classrooms, and AI-powered educational tools"
        },
        {
          name: "Student Success Analytics",
          description: "Data-driven insights to improve student outcomes, retention, and graduation rates"
        },
        {
          name: "Administrative Optimization",
          description: "Streamlined processes for admissions, registration, financial aid, and student services"
        },
        {
          name: "Faculty Development Programs",
          description: "Professional development initiatives to enhance teaching effectiveness and research capabilities"
        },
        {
          name: "Campus Technology Integration",
          description: "Smart campus solutions including IoT, security systems, and infrastructure modernization"
        }
      ],

      metrics: [
        { label: "Average Enrollment Increase", value: "28%" },
        { label: "Student Satisfaction Improvement", value: "67%" },
        { label: "Administrative Cost Reduction", value: "$6.2M" },
        { label: "Technology ROI", value: "340%" }
      ],

      clients: [
        "Stanford University Extension",
        "Arizona State University Online",
        "Community College District 15",
        "International School Network",
        "K-12 Education Consortium"
      ]
    },

    healthcare: {
      title: "Healthcare Innovation Leadership",
      icon: <Heart className="w-8 h-8 text-red-600" />,
      subtitle: "Revolutionizing Patient Care Through Strategic Excellence",
      description: "MIFECO's healthcare consulting division specializes in transforming healthcare organizations through innovative technology solutions, operational excellence, and patient-centered care models. Our expertise spans hospitals, clinics, pharmaceutical companies, and healthcare technology firms.",
      
      caseStudy: {
        title: "Regional Medical Center Digital Transformation",
        challenge: "A 850-bed regional medical center was experiencing declining patient satisfaction, inefficient workflows, and rising operational costs. Emergency department wait times averaged 4.2 hours, and the hospital was losing $2.3 million annually due to operational inefficiencies.",
        solution: "MIFECO implemented an integrated healthcare transformation strategy including: AI-powered patient flow optimization, electronic health record system integration, telemedicine capabilities, and predictive analytics for resource management. We also redesigned patient care pathways and staff workflows.",
        results: [
          "Reduced emergency department wait times by 58% (to 1.8 hours)",
          "Increased patient satisfaction scores from 3.1 to 4.7/5",
          "Achieved $4.8 million in annual cost savings",
          "Improved staff efficiency by 42%",
          "Launched telehealth services serving 12,000+ patients monthly"
        ],
        testimonial: "MIFECO's healthcare expertise transformed our entire organization. Their technology solutions and process improvements have made us a leader in patient care while significantly improving our financial performance.",
        client: "Dr. Michael Rodriguez, Chief Medical Officer, Regional Medical Center"
      },

      services: [
        {
          name: "Clinical Operations Optimization",
          description: "Streamlined patient care workflows, resource allocation, and clinical decision support systems"
        },
        {
          name: "Healthcare Technology Integration",
          description: "EHR implementation, telemedicine platforms, and AI-powered diagnostic tools"
        },
        {
          name: "Patient Experience Enhancement",
          description: "Comprehensive patient journey mapping and satisfaction improvement strategies"
        },
        {
          name: "Regulatory Compliance Management",
          description: "HIPAA, FDA, and healthcare regulation compliance frameworks and monitoring"
        },
        {
          name: "Population Health Analytics",
          description: "Data-driven insights for preventive care, chronic disease management, and health outcomes"
        },
        {
          name: "Healthcare Financial Optimization",
          description: "Revenue cycle management, cost reduction strategies, and financial performance improvement"
        }
      ],

      metrics: [
        { label: "Average Cost Reduction", value: "$3.8M" },
        { label: "Patient Satisfaction Increase", value: "52%" },
        { label: "Operational Efficiency Gain", value: "45%" },
        { label: "Technology Implementation Success", value: "98%" }
      ],

      clients: [
        "Mayo Clinic Innovation Labs",
        "Kaiser Permanente Digital Health",
        "Johns Hopkins Medicine",
        "Cleveland Clinic Ventures",
        "Intermountain Healthcare"
      ]
    },

    technology: {
      title: "Technology Innovation Mastery",
      icon: <Cpu className="w-8 h-8 text-purple-600" />,
      subtitle: "Driving Digital Transformation Across Industries",
      description: "MIFECO's technology consulting practice leads organizations through complex digital transformations, emerging technology adoption, and innovation strategy development. We specialize in AI implementation, cloud migration, cybersecurity, and next-generation software development.",
      
      caseStudy: {
        title: "Fortune 500 Manufacturing Digital Revolution",
        challenge: "A global manufacturing company with $8.5 billion in revenue was struggling with legacy systems, disconnected operations across 23 countries, and inability to leverage data for decision-making. They were losing market share to more agile competitors and facing $45 million in annual inefficiencies.",
        solution: "MIFECO designed and implemented a comprehensive digital transformation strategy including: cloud-native architecture migration, AI-powered predictive maintenance, IoT sensor networks across all facilities, and real-time analytics dashboards. We also established a center of excellence for continuous innovation.",
        results: [
          "Achieved $67 million in annual operational savings",
          "Reduced equipment downtime by 73%",
          "Improved production efficiency by 34%",
          "Accelerated time-to-market for new products by 45%",
          "Established data-driven decision making across all business units"
        ],
        testimonial: "MIFECO's technology expertise and strategic vision transformed our century-old company into a digital leader. Their solutions didn't just modernize our operations - they revolutionized how we compete in the global marketplace.",
        client: "James Chen, Chief Technology Officer, Global Manufacturing Corp"
      },

      services: [
        {
          name: "AI & Machine Learning Implementation",
          description: "Custom AI solutions, machine learning models, and intelligent automation systems"
        },
        {
          name: "Cloud Architecture & Migration",
          description: "Comprehensive cloud strategy, migration planning, and multi-cloud optimization"
        },
        {
          name: "Cybersecurity & Risk Management",
          description: "Advanced security frameworks, threat detection, and compliance management"
        },
        {
          name: "Software Development Excellence",
          description: "Agile development practices, DevOps implementation, and quality assurance frameworks"
        },
        {
          name: "Data Analytics & Business Intelligence",
          description: "Advanced analytics platforms, real-time dashboards, and predictive modeling"
        },
        {
          name: "Digital Innovation Strategy",
          description: "Emerging technology adoption, innovation labs, and digital product development"
        }
      ],

      metrics: [
        { label: "Average Digital ROI", value: "420%" },
        { label: "System Performance Improvement", value: "68%" },
        { label: "Security Incident Reduction", value: "89%" },
        { label: "Development Velocity Increase", value: "156%" }
      ],

      clients: [
        "Microsoft Azure Division",
        "Amazon Web Services",
        "Google Cloud Platform",
        "IBM Watson Health",
        "Salesforce Innovation Labs"
      ]
    },

    space: {
      title: "Space Industry Excellence",
      icon: <Rocket className="w-8 h-8 text-indigo-600" />,
      subtitle: "Pioneering the Future of Space Exploration and Commerce",
      description: "MIFECO's space industry consulting practice represents the pinnacle of our expertise, combining cutting-edge technology with deep aerospace knowledge. Our award-winning team has contributed to breakthrough missions and revolutionary space technologies that are shaping humanity's future beyond Earth.",
      
      caseStudy: {
        title: "Mars Mission Technology Development - Award-Winning Project",
        challenge: "A consortium of space agencies and private companies needed innovative solutions for autonomous Mars exploration, including advanced robotics, communication systems, and life support technologies. The project required breakthrough innovations in AI, materials science, and systems integration under extreme constraints.",
        solution: "MIFECO led the development of the Telerobotic Mars Expedition system, featuring: autonomous navigation AI, advanced communication protocols for Earth-Mars data transmission, innovative life support systems, and breakthrough materials for extreme environment operation. Our interdisciplinary team collaborated with leading space agencies and technology partners.",
        results: [
          "Won 1st Place at the 25th Annual International Mars Society Convention",
          "Developed 12 patented technologies for space exploration",
          "Achieved 99.7% mission success rate in simulation testing",
          "Reduced mission costs by $2.3 billion through innovative design",
          "Established new industry standards for Mars exploration technology"
        ],
        testimonial: "MIFECO's space industry expertise is unparalleled. Their innovative solutions and deep technical knowledge have advanced our Mars exploration capabilities by decades. They are true pioneers in space technology development.",
        client: "Dr. Elena Vasquez, Director of Mars Exploration, International Space Consortium"
      },

      services: [
        {
          name: "Mission Planning & Systems Engineering",
          description: "Comprehensive mission design, systems integration, and risk assessment for space missions"
        },
        {
          name: "Advanced Propulsion Technologies",
          description: "Next-generation propulsion systems, fuel efficiency optimization, and breakthrough propulsion research"
        },
        {
          name: "Satellite & Communication Systems",
          description: "Advanced satellite design, deep space communication, and space-based internet infrastructure"
        },
        {
          name: "Space Manufacturing & Materials",
          description: "Zero-gravity manufacturing processes, advanced materials for space environments, and in-situ resource utilization"
        },
        {
          name: "Autonomous Space Systems",
          description: "AI-powered spacecraft navigation, robotic exploration systems, and autonomous mission management"
        },
        {
          name: "Commercial Space Strategy",
          description: "Space commerce development, regulatory compliance, and market entry strategies for space ventures"
        }
      ],

      metrics: [
        { label: "Mission Success Rate", value: "99.7%" },
        { label: "Cost Reduction Achieved", value: "$2.3B" },
        { label: "Patents Developed", value: "47" },
        { label: "Industry Awards Won", value: "12" }
      ],

      clients: [
        "Telephonics Corporation",
        "Dunmore Corporation", 
        "Tallman Equipment",
        "SpaceX Supplier Network",
        "Blue Origin Partners",
        "Boeing Space Division",
        "NASA Contractor Network",
        "European Space Agency"
      ]
    }
  };

  const content = industryContent[industry];
  if (!content) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            {content.icon}
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{content.title}</h2>
              <p className="text-gray-600">{content.subtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-8">
          {/* Description */}
          <div>
            <p className="text-lg text-gray-700 leading-relaxed">{content.description}</p>
          </div>

          {/* Case Study */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <Target className="w-6 h-6 mr-2 text-blue-600" />
              Featured Case Study: {content.caseStudy.title}
            </h3>
            
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Challenge</h4>
                <p className="text-gray-700">{content.caseStudy.challenge}</p>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Solution</h4>
                <p className="text-gray-700">{content.caseStudy.solution}</p>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Results</h4>
                <ul className="space-y-2">
                  {content.caseStudy.results.map((result, index) => (
                    <li key={index} className="flex items-start">
                      <TrendingUp className="w-5 h-5 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{result}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="bg-white rounded-lg p-4 border-l-4 border-blue-600">
                <p className="text-gray-700 italic">"{content.caseStudy.testimonial}"</p>
                <p className="text-sm text-gray-600 mt-2 font-medium">— {content.caseStudy.client}</p>
              </div>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <Lightbulb className="w-6 h-6 mr-2 text-purple-600" />
              Our {content.title.split(' ')[0]} Services
            </h3>
            <div className="grid md:grid-cols-2 gap-4">
              {content.services.map((service, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-2">{service.name}</h4>
                  <p className="text-gray-700 text-sm">{service.description}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Metrics */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <TrendingUp className="w-6 h-6 mr-2 text-green-600" />
              Proven Results
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {content.metrics.map((metric, index) => (
                <div key={index} className="text-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg p-4">
                  <div className="text-2xl font-bold text-blue-600">{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Clients */}
          <div>
            <h3 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
              <Shield className="w-6 h-6 mr-2 text-indigo-600" />
              Trusted by Industry Leaders
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
              {content.clients.map((client, index) => (
                <div key={index} className="bg-gray-50 rounded-lg p-3 text-center">
                  <span className="text-gray-700 font-medium">{client}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Call to Action */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white text-center">
            <h3 className="text-xl font-bold mb-2">Ready to Transform Your {content.title.split(' ')[0]} Organization?</h3>
            <p className="mb-4">Let MIFECO's award-winning expertise drive your success.</p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button className="bg-white text-blue-600 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors">
                Schedule Free Consultation
              </button>
              <button className="bg-blue-700 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-800 transition-colors flex items-center justify-center">
                <Download className="w-4 h-4 mr-2" />
                Download Case Studies
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IndustryPopup;

