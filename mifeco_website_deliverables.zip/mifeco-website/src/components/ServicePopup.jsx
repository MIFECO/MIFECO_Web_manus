import React, { useState } from 'react';
import { X, ArrowRight, CheckCircle, Star, Users, TrendingUp, Target, BarChart3, Shield, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

const ServicePopup = ({ service, isOpen, onClose }) => {
  if (!isOpen) return null;

  const serviceContent = {
    'Strategic Planning': {
      title: 'Strategic Planning Excellence',
      subtitle: 'Transform Your Vision Into Actionable Results',
      story: `When TechNova Solutions approached MIFECO, they were a promising startup with innovative AI technology but lacked a clear path to market dominance. Their brilliant engineers had created groundbreaking algorithms, but they struggled with strategic direction, market positioning, and scaling challenges that threatened to derail their growth trajectory.

Our strategic planning engagement began with a comprehensive 360-degree business assessment. We conducted in-depth stakeholder interviews, analyzed market dynamics, and evaluated their competitive landscape. What we discovered was a company with exceptional technical capabilities but fragmented strategic focus across multiple market segments.

Through our proven strategic planning methodology, we helped TechNova identify their core value proposition and develop a laser-focused go-to-market strategy. We facilitated strategic planning sessions that aligned their leadership team around three key market opportunities, prioritized their product development roadmap, and established clear performance metrics for success.

The transformation was remarkable. Within 18 months of implementing our strategic plan, TechNova secured $15M in Series A funding, expanded their team from 12 to 45 employees, and established partnerships with three Fortune 500 companies. Their revenue grew by 340%, and they successfully positioned themselves as the leading AI solution provider in their target market.

This success story exemplifies MIFECO's approach to strategic planning - we don't just create documents, we build executable roadmaps that drive measurable business outcomes. Our strategic planning process combines rigorous analysis with creative problem-solving, ensuring that every recommendation is both ambitious and achievable.`,
      benefits: [
        'Comprehensive business assessment and market analysis',
        'Leadership alignment and strategic consensus building',
        'Actionable roadmaps with clear milestones and metrics',
        'Competitive positioning and differentiation strategies',
        'Risk assessment and mitigation planning',
        'Performance tracking and optimization frameworks'
      ],
      caseStudy: {
        client: 'TechNova Solutions',
        challenge: 'Fragmented strategic focus and unclear market positioning',
        solution: 'Comprehensive strategic planning and go-to-market strategy',
        results: ['340% revenue growth', '$15M Series A funding', '3 Fortune 500 partnerships']
      },
      icon: <Target className="w-8 h-8" />,
      color: 'from-blue-500 to-blue-600'
    },
    'Growth Optimization': {
      title: 'Growth Optimization Mastery',
      subtitle: 'Unlock Hidden Revenue Potential',
      story: `MedTech Innovations had plateaued at $8M in annual revenue despite having a revolutionary medical device that could transform patient care. Their sales team was working harder than ever, but growth had stagnated for 18 months. The leadership team was frustrated, knowing they had a superior product but couldn't break through to the next level of success.

MIFECO's growth optimization engagement revealed critical bottlenecks in their sales process, customer acquisition strategy, and operational efficiency. Through detailed data analysis and customer journey mapping, we identified that their sales cycle was 40% longer than industry standards, their customer acquisition cost was increasing, and they were losing qualified prospects due to process inefficiencies.

Our growth optimization strategy focused on three key areas: sales process optimization, customer experience enhancement, and operational scalability. We implemented a data-driven sales methodology, redesigned their customer onboarding process, and established automated systems for lead nurturing and customer success management.

We also identified untapped market segments and developed targeted expansion strategies. Our team worked closely with their sales and marketing departments to implement new tools, processes, and performance metrics that would drive sustainable growth.

The results exceeded all expectations. Within 12 months, MedTech Innovations achieved 180% revenue growth, reaching $14.4M in annual revenue. Their sales cycle decreased by 35%, customer acquisition costs dropped by 28%, and customer lifetime value increased by 65%. Most importantly, they built scalable systems that continue to drive growth long after our engagement ended.

This transformation demonstrates MIFECO's unique ability to identify growth levers that others miss and implement solutions that deliver both immediate results and long-term sustainability.`,
      benefits: [
        'Revenue optimization and growth acceleration',
        'Sales process improvement and automation',
        'Customer acquisition cost reduction',
        'Market expansion and penetration strategies',
        'Operational efficiency and scalability',
        'Performance analytics and continuous optimization'
      ],
      caseStudy: {
        client: 'MedTech Innovations',
        challenge: 'Revenue plateau and inefficient sales processes',
        solution: 'Comprehensive growth optimization and process redesign',
        results: ['180% revenue growth', '35% faster sales cycle', '28% lower acquisition costs']
      },
      icon: <TrendingUp className="w-8 h-8" />,
      color: 'from-green-500 to-green-600'
    },
    'Digital Transformation': {
      title: 'Digital Transformation Leadership',
      subtitle: 'Modernize Operations for Competitive Advantage',
      story: `Heritage Manufacturing, a 75-year-old family business, was struggling to compete in an increasingly digital marketplace. Their manual processes, paper-based systems, and outdated technology infrastructure were creating operational inefficiencies and limiting their ability to serve modern customers who expected digital experiences.

The company's leadership recognized the need for digital transformation but felt overwhelmed by the complexity and risk involved. They had attempted several technology initiatives in the past, but these efforts had failed to deliver meaningful results and had created skepticism about digital change within the organization.

MIFECO's digital transformation approach began with a comprehensive technology audit and organizational readiness assessment. We evaluated their existing systems, processes, and capabilities while also assessing their team's readiness for digital change. Our analysis revealed opportunities to modernize their operations while preserving the craftsmanship and quality that had made them successful for decades.

Our transformation strategy focused on gradual, strategic implementation rather than disruptive overhaul. We designed a phased approach that modernized their core business processes, implemented cloud-based systems for improved collaboration and data access, and established digital customer touchpoints that enhanced their service delivery.

We also prioritized change management and employee training, ensuring that their team embraced the new technologies and processes. Our approach respected their company culture while introducing modern capabilities that would drive future growth.

The digital transformation delivered remarkable results. Heritage Manufacturing reduced operational costs by 32%, improved customer satisfaction scores by 45%, and increased their market reach by 150% through new digital channels. Their order processing time decreased from 5 days to 2 hours, and they gained real-time visibility into their operations that enabled better decision-making.

Most importantly, the transformation positioned Heritage Manufacturing for continued success in the digital economy while preserving the values and quality that had defined their brand for three generations.`,
      benefits: [
        'Technology infrastructure modernization',
        'Process automation and efficiency gains',
        'Digital customer experience enhancement',
        'Data analytics and business intelligence',
        'Change management and employee training',
        'Scalable systems for future growth'
      ],
      caseStudy: {
        client: 'Heritage Manufacturing',
        challenge: 'Outdated systems and manual processes limiting growth',
        solution: 'Phased digital transformation with change management',
        results: ['32% cost reduction', '45% higher satisfaction', '150% market reach expansion']
      },
      icon: <Zap className="w-8 h-8" />,
      color: 'from-purple-500 to-purple-600'
    },
    'Team Development': {
      title: 'Team Development Excellence',
      subtitle: 'Build High-Performance Organizations',
      story: `Quantum Research Labs had assembled a team of brilliant scientists and engineers, but their innovative potential was being undermined by communication breakdowns, unclear roles, and leadership challenges. Despite having world-class talent, their projects were consistently delayed, team morale was declining, and their competitive advantage was eroding.

The company's founder, a renowned physicist, excelled at scientific innovation but struggled with the people management aspects of scaling a research organization. Team members were working in silos, duplicating efforts, and failing to leverage their collective expertise effectively.

MIFECO's team development engagement began with comprehensive assessments of individual strengths, team dynamics, and organizational culture. We conducted confidential interviews with all team members, analyzed communication patterns, and evaluated their current leadership and management practices.

Our team development strategy addressed multiple levels: individual skill development, team collaboration enhancement, and organizational culture transformation. We implemented leadership training programs for key managers, established clear communication protocols, and created cross-functional project teams that leveraged diverse expertise.

We also introduced performance management systems that aligned individual goals with organizational objectives, established mentorship programs that accelerated professional development, and created innovation frameworks that channeled their creative energy more effectively.

The transformation was profound. Within 9 months, Quantum Research Labs reduced project completion times by 40%, increased employee satisfaction scores by 60%, and achieved breakthrough innovations that led to three new patent applications. Team collaboration improved dramatically, and they successfully launched two new product lines that generated $12M in additional revenue.

The leadership team gained confidence in their management capabilities, and the organization developed a culture of continuous learning and innovation that continues to drive their success. This engagement demonstrates MIFECO's ability to unlock human potential and create high-performance teams that achieve extraordinary results.`,
      benefits: [
        'Leadership development and management training',
        'Team collaboration and communication enhancement',
        'Performance management system implementation',
        'Organizational culture transformation',
        'Talent development and retention strategies',
        'Innovation and creativity frameworks'
      ],
      caseStudy: {
        client: 'Quantum Research Labs',
        challenge: 'Talented team with poor collaboration and leadership gaps',
        solution: 'Comprehensive team development and culture transformation',
        results: ['40% faster project completion', '60% higher satisfaction', '$12M new revenue']
      },
      icon: <Users className="w-8 h-8" />,
      color: 'from-orange-500 to-orange-600'
    },
    'Performance Analytics': {
      title: 'Performance Analytics Mastery',
      subtitle: 'Data-Driven Decision Making for Superior Results',
      story: `DataFlow Enterprises was drowning in information but starving for insights. Despite collecting vast amounts of data from their operations, they lacked the analytical capabilities to transform this information into actionable intelligence. Their decision-making was still largely intuition-based, and they were missing critical opportunities to optimize their performance.

The company's executives knew that their competitors were gaining advantages through better use of analytics, but they struggled to identify which metrics mattered most and how to implement effective measurement systems. Their existing reports were overwhelming and often contradictory, making it difficult to understand their true performance drivers.

MIFECO's performance analytics engagement began with a comprehensive audit of their existing data sources, reporting systems, and decision-making processes. We identified gaps in their measurement capabilities and opportunities to leverage their data more effectively for strategic advantage.

Our analytics strategy focused on creating a unified performance measurement framework that aligned with their business objectives. We implemented advanced analytics tools, established key performance indicators (KPIs) that truly mattered for their success, and created automated dashboards that provided real-time visibility into their operations.

We also trained their team on data interpretation and analytical thinking, ensuring they could leverage these new capabilities independently. Our approach emphasized practical application rather than theoretical knowledge, focusing on how analytics could drive better business decisions.

The performance analytics transformation delivered immediate and sustained value. DataFlow Enterprises improved their operational efficiency by 35%, identified new revenue opportunities worth $8M annually, and reduced costs by 22% through better resource allocation. Their decision-making speed increased by 50%, and they gained competitive advantages through predictive analytics capabilities.

Most importantly, they developed a data-driven culture that continues to drive innovation and optimization across their organization. This engagement showcases MIFECO's expertise in transforming raw data into strategic competitive advantages.`,
      benefits: [
        'Advanced analytics implementation and automation',
        'Key performance indicator (KPI) development',
        'Real-time dashboard and reporting systems',
        'Predictive analytics and forecasting capabilities',
        'Data-driven decision making training',
        'Performance optimization and continuous improvement'
      ],
      caseStudy: {
        client: 'DataFlow Enterprises',
        challenge: 'Data-rich but insight-poor decision making',
        solution: 'Comprehensive performance analytics framework',
        results: ['35% efficiency improvement', '$8M new opportunities', '22% cost reduction']
      },
      icon: <BarChart3 className="w-8 h-8" />,
      color: 'from-pink-500 to-pink-600'
    },
    'Risk Management': {
      title: 'Risk Management Excellence',
      subtitle: 'Protect and Strengthen Your Business Foundation',
      story: `SecureVentures Inc. was experiencing rapid growth in the cybersecurity sector, but their success was creating new vulnerabilities and operational risks that threatened their future. As they scaled from a startup to a mid-size company, they discovered that their informal risk management approaches were no longer adequate for their expanded operations and increased regulatory requirements.

The company faced multiple risk categories: cybersecurity threats, regulatory compliance challenges, operational vulnerabilities, financial risks, and reputational concerns. Their leadership team was spending increasing amounts of time on crisis management rather than strategic growth, and they recognized the need for a comprehensive risk management framework.

MIFECO's risk management engagement began with a thorough risk assessment across all aspects of their business. We identified, categorized, and prioritized risks based on their potential impact and likelihood of occurrence. Our analysis revealed critical vulnerabilities that could have resulted in significant business disruption if left unaddressed.

Our risk management strategy established a comprehensive framework that included risk identification processes, mitigation strategies, contingency planning, and ongoing monitoring systems. We implemented governance structures that ensured appropriate oversight and accountability for risk management across the organization.

We also developed crisis response protocols, business continuity plans, and recovery procedures that would enable the company to maintain operations during adverse events. Our approach balanced risk mitigation with business agility, ensuring that risk management enhanced rather than hindered their growth objectives.

The risk management transformation provided both immediate protection and long-term strategic value. SecureVentures Inc. successfully navigated a major cybersecurity incident that could have been devastating, maintained compliance during a regulatory audit that resulted in expanded market access, and avoided operational disruptions that affected several of their competitors.

Their insurance costs decreased by 18% due to improved risk profiles, and they gained competitive advantages by being able to take calculated risks that their competitors couldn't manage effectively. This engagement demonstrates MIFECO's ability to transform risk from a constraint into a competitive advantage.`,
      benefits: [
        'Comprehensive risk assessment and prioritization',
        'Risk mitigation strategies and implementation',
        'Business continuity and disaster recovery planning',
        'Regulatory compliance and governance frameworks',
        'Crisis management and response protocols',
        'Insurance optimization and cost reduction'
      ],
      caseStudy: {
        client: 'SecureVentures Inc.',
        challenge: 'Rapid growth creating multiple operational and strategic risks',
        solution: 'Comprehensive risk management framework and protocols',
        results: ['Successful crisis navigation', '18% insurance cost reduction', 'Competitive risk advantages']
      },
      icon: <Shield className="w-8 h-8" />,
      color: 'from-red-500 to-red-600'
    }
  };

  const content = serviceContent[service];
  if (!content) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-white border-b p-6 flex items-center justify-between rounded-t-3xl">
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 rounded-2xl bg-gradient-to-r ${content.color} flex items-center justify-center text-white`}>
              {content.icon}
            </div>
            <div>
              <h2 className="text-2xl font-bold">{content.title}</h2>
              <p className="text-gray-600">{content.subtitle}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-6 space-y-8">
          {/* Success Story */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-500" />
              <h3 className="text-xl font-semibold">Success Story</h3>
            </div>
            <div className="prose prose-gray max-w-none">
              <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                {content.story}
              </p>
            </div>
          </div>

          {/* Case Study Highlights */}
          <Card className="bg-gradient-to-r from-gray-50 to-blue-50">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                <span>Case Study Highlights</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Client</h4>
                  <p className="text-gray-700">{content.caseStudy.client}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Challenge</h4>
                  <p className="text-gray-700">{content.caseStudy.challenge}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Solution</h4>
                  <p className="text-gray-700">{content.caseStudy.solution}</p>
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Results Achieved</h4>
                <div className="flex flex-wrap gap-2">
                  {content.caseStudy.results.map((result, index) => (
                    <Badge key={index} className="bg-green-100 text-green-700">
                      {result}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Key Benefits */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span>How MIFECO Can Help You</span>
            </h3>
            <div className="grid md:grid-cols-2 gap-3">
              {content.benefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-700">{benefit}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Call to Action */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6 text-center space-y-4">
            <h3 className="text-xl font-semibold">Ready to Transform Your Business?</h3>
            <p className="text-gray-600">
              Let's discuss how MIFECO can help you achieve similar results in your organization.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button className="btn-gradient text-white">
                Schedule Free Consultation
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button variant="outline">
                Download Case Study
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServicePopup;

